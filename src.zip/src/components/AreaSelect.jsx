// src/components/AreaSelect.jsx
import { useState, useEffect } from 'react';
import { supabase } from '../supabaseClient'; // <--- AJUSTE ESSE CAMINHO SE NECESSÁRIO

export default function AreaSelect({ currentTenantId, selectedAreaId, onSelectArea }) {
  const [departments, setDepartments] = useState([]);
  const [isCreatingNew, setIsCreatingNew] = useState(false);
  const [newDeptName, setNewDeptName] = useState('');
  const [loading, setLoading] = useState(true);

  // Busca as áreas apenas da empresa logada
  useEffect(() => {
    if (!currentTenantId) return;

    async function fetchDepartments() {
      try {
        const { data, error } = await supabase
          .from('company_departments')
          .select('id, name')
          .eq('tenantId', currentTenantId) // Filtro de segurança
          .order('name', { ascending: true });

        if (error) throw error;
        setDepartments(data || []);
      } catch (error) {
        console.error('Erro ao buscar áreas:', error.message);
      } finally {
        setLoading(false);
      }
    }

    fetchDepartments();
  }, [currentTenantId]);

  // Salva uma nova área no banco
  const handleSaveNew = async () => {
    if (!newDeptName.trim()) return;

    try {
      const { data, error } = await supabase
        .from('company_departments')
        .insert([{ 
          name: newDeptName.trim(), 
          tenantId: currentTenantId 
        }])
        .select()
        .single();

      if (error) throw error;

      // Atualiza a lista local e seleciona o novo item
      setDepartments([...departments, data]);
      onSelectArea(data.id); // Avisa o pai que selecionou este ID
      setIsCreatingNew(false);
      setNewDeptName('');
    } catch (error) {
      alert('Erro ao criar área: ' + error.message);
    }
  };

  if (loading) return <div className="text-xs text-gray-500">Carregando áreas...</div>;

  return (
    <div className="mb-4">
      <label className="block text-sm font-medium text-gray-700 mb-1">Área / Departamento</label>
      
      {!isCreatingNew ? (
        <select
          className="block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500 sm:text-sm p-2 border"
          value={selectedAreaId || ''}
          onChange={(e) => {
            if (e.target.value === 'NEW') setIsCreatingNew(true);
            else onSelectArea(e.target.value);
          }}
        >
          <option value="">Selecione uma área...</option>
          {departments.map((dept) => (
            <option key={dept.id} value={dept.id}>{dept.name}</option>
          ))}
          <option value="NEW" className="font-bold text-blue-600">+ Criar nova área...</option>
        </select>
      ) : (
        <div className="flex gap-2 items-center mt-1">
          <input
            type="text"
            className="block w-full rounded-md border-gray-300 shadow-sm focus:ring-blue-500 focus:border-blue-500 sm:text-sm p-2 border"
            placeholder="Nome da nova área (ex: Comercial)"
            value={newDeptName}
            onChange={(e) => setNewDeptName(e.target.value)}
            autoFocus
          />
          <button
            type="button"
            onClick={handleSaveNew}
            className="bg-blue-600 text-white px-3 py-2 rounded text-sm hover:bg-blue-700"
          >
            Salvar
          </button>
          <button
            type="button"
            onClick={() => setIsCreatingNew(false)}
            className="text-red-500 hover:text-red-700 text-sm underline px-2"
          >
            Cancelar
          </button>
        </div>
      )}
    </div>
  );
}
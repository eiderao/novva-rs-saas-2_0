export default function CompanySettings() {
  return (
    <div className="p-8">
      <h1 className="text-2xl font-bold mb-4">Configurações da Empresa</h1>
      <p>Página em construção.</p>
    </div>
  );
}